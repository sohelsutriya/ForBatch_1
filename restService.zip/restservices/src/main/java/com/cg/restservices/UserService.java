package com.cg.restservices;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	@Autowired
	//@Qualifier("")
	//private UserInMemoryRepository userRepos;
	private UserJpaRepository userRepos;

	public List<User> findAll() {
		System.out.println("inside findAll() of Service");
		return userRepos.findAll();
	}
	public User findById(int id) {
		System.out.println("inside findById() of service");
		Optional<User> user= userRepos.findById(id);
		return user.get();
	}
	public User createUser(User user) {
		System.out.println("inside createaUser() of service");
		userRepos.save(user);
		return user;
	}
	public void deleteUser(int id) {
		System.out.println("inside deleteUser() of service");
		userRepos.deleteById(id);
		
	}
	public void updateUser(User user) {
		System.out.println("inside updateUser() of service");
		userRepos.deleteById(user.getId());
		userRepos.save(user);
		
	}
}
