package com.cg.restservices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository(value="datajpa")
public interface UserJpaRepository extends JpaRepository<User, Integer> {
	
}
