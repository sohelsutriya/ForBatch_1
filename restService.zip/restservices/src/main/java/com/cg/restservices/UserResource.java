package com.cg.restservices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserResource {
	@Autowired
	private UserService service;

	// @RequestMapping(value = "/users", method = RequestMethod.GET)
	@GetMapping(path = "/users")
	public List<User> retrieveAllUsers() {
		System.out.println("inside retrieveAllUsers() of Controller");
		return service.findAll();
	}

	@GetMapping(path = "/users/{id}")
	public User retrieveUserById(@PathVariable int id) {
		System.out.println("inside retrieveUser() of Controller");
		User user = service.findById(id);
		System.out.println("returned user " + user);
		if (user != null)
			return user;
		else
			throw new UserNotFoundException("User not found");
	}

	@PostMapping(path = "/users")
	public void createUser(@RequestBody User user) {
		System.out.println("inside createUser() of Controller");
		User savedUser = service.createUser(user);
	}

	@DeleteMapping(path = "/users/{id}")
	public void deleteUser(@PathVariable int id) {
		service.deleteUser(id);
	}

	@PutMapping(path = "/users")
	public void updateUser(@RequestBody User user) {
		System.out.println("inside createUser() of Controller");
		service.updateUser(user);
	}
}
